# Introduction-to-Deep-Learning
## Anand Krishnamoorthy

## Course Grade: A 

## Week 1 - 22 June to 28 June

Topics covered:

Course information

ML introduction and examples

  Supervised
  
    •	Linear Discriminant Analysis (LDA)
    •	Quadratic Discriminant Analysis (QDA)
    •	K Nearest Neighbors (KNN)
   
   UnSupervised
   
    •	K-means Clustering    
    •	Hierarchical Clustering
  
Deep Learning intoduction 

  Different Activation functions
  
    •	relu (NN may get stuck in local optima, 
    becauce derivative becomes 0 when function is less than 0, so no further updates in weights)    
    •	tanh    
    •	sigmoid
    
  Architecture
  
    Constists of Input layer, Hidden Layer and Ouput layer
    
Loss function and cost functions
  
  Loss function - Loss for 1 example
  
  Cost function - sum of the losses for all the examples
    
    Examples- mean squared error, mean absolute error, categorical crossentropy.
  

Gradient descent, SGD, Mini Batch Gradient descent
  
  Mini Batch Gradient descent & Stochastic Gradient Descent are faster.
  
  Some Stochastic behaviour is preferred
  
Training NN
  
  Weight are calculated at each layer using chain rule.
  
  Weights are calulated first during forward propogation.
  
  Based on the errors on each layer, weights are updated during back propogation. 
  (chain rule & partial derivatives rules are applied)

## Week 2 - 29 June to 5 July
Neural Network Hyperparameter

  Number of hidden layers
    
    •	NN with one hidden layer can approximate any dependence, 
    provided there are sufficient number of neurons in the layer
    •	Deep NNs have higher parameter efficiency, i.e. require less parameters to model same dependence.
    •	Lower hiddenlayers can be reused for other similar problems.
  
  Number of neurons in each layer
  
    It is optimal to decrease the number of neurons as one moves from layer to layer. 
    Low-level structures need more neurons.
  
  Activation Functions
    
    Choice of activation functions may significantly impact convergence/result because of 
    vanishing/exploding gradients problems
  
  Batch Size
  
  Number of epochs
  
  Regularization
    
    L1 & L2 Regulatization
      •	alpha parameter controls the degree of regularization
      •	Different layers can have different aplha parameter
    Dropout
     •	Random number of neurons during every training step.
     •	Weights are rescaled to accomodate for missing neurons. 
     •	If r is dropout rate weights are rescaled by (1-r)
   
   Vanishing/Exploding Gradients Problems
   
    Techniques to Alleviate the Unstable Gradient Problem    
      •	"Proper" initialization of weights: special initial distribution, reusing pretrained layers, etc.
      •	Use Nonsaturating activations functons: Leaky ReLU
      •	Batch normalization (BN)
      •	Gradient clipping
      
   Neural Network Optimization Algorithms
     •	Choice of Neural Network affects speed of convergance.
    
    Affects whether it reaches local or global minima.    
      •	SGD, Mini-batch GD, and GD
      •	Momentum Optimization
      •	Nestrov Acclerated Gradient (NAG)
      •	AdaGrad
      •	RMSProp
      •	Adam - Proven to work the best in most cases. Even the deafault paramaters work best in most cases.
      
## Week 3 - 6 July to 12 July

Alleviate unstable Gradient problem
    
    Better activation functions
       •	Leaky ReLU - ReLU may cause some neurons to go dead.
       •	Maxout
       •	ELU
 
     Initialization of weights
       •	Glorot normal, Glorot Uniform initialization. - Ideal for Sigmoid, Tanh, or Softmax. 
       Glorot normal is the default initialization in keras
       •	He initialization - Ideal for ReLU, Leaky ReLU, ELU
     
     Batch Normalization
        •	Signal variance increases from input layer to the output layer. Therefore, Batch Normalization is done.
        More beneficial when done in the later layers.

     Gradient Clipping
        •	Set an upper threshold on gradients.
        
     Learning rate decay
        •	Learning rate not an optimal choice in many cases. So a decay term is introduced.
        
Pretrained Layers
    
    •	Use part of the existing well known architectures. Some layers will use fixed weights. 
    Some will have trainable weights. Further layers can be added(example a dense layer and output layer)
    Mostly used for CNN architecture, since for other archirectures like the RNN, weights are shared across units.
    
    •	Example: Inception V3, ResNet50, VGG16, VGG19.

Convolution Neural Networks (CNNs)
      
    •	Convolutions can be used for edge detection. These are identified by the Neural network automatically.  
    •	Covoluation layer are used in combination with pooling layers.
    •	Ideology is you need not see the entire image/object. Just look at neighbeoring pixels.

## Week 4 - 13 July to 19 July
Convolution Neural Networks (CNNs) contd. 

  Convolution layer acts as filters, for example horizontal and vertical filters. The neural network will automatically learn to identify these filters.
    
    •	Padding: Keras options: 'SAME' or 'VALID'.
    •	Strides: Help in dimension reduction.
    •	Local Response Normalization (LRN): Similar to bacth normalization. LRN helps in reducing the variance of signals.
    •	Image Augmentation: Available in Imagegenerator class in Keras. Options available: zoom, rotate, horizontal flip etc.

Transfer Learning
  Use famous CNN architecture for our tasks.
  
    •	AlexNet (2012): 60 Million total parameters. 17% top-5 error rate.
    •	GoogLeNet (2014): 6 Million total parameters. 7% top-5 error rate. 
    Much deeper than previous models. Inception module makes it go deeper.
    •	ResNet (2015): 3.6% top-5 error rate. Skip connection used.
    Input directly connected to the output layer and the model is then trained.
    
Recurrent Neural Network (RNNs)

Current prediction can be based on past events. 
These can be used in applications like Timeseries prediction, Language translation, Image captioning etc.
They can process variable imput leghts.

Inputs:
  
    •	n_timesteps: How far previous data needs to be looked at to make current prediction.
    •	n_features: Dimensions of input. Example: columns in input. 
    Temperature can be based on past temperatures, humidity, season, time of day etc.
    •	No:of RNNs: defines output dimension.
Memory cells:
  Past predictions can be used to predict current prediction.
  
Long short-Term Memory (LSTM)
  
    •	Forget Gate, Input gate, and Output gate.
    c - long term memory cell, h- short term memory cell.
Input and Output sequences of RNNs:
  
    •	Sequence to Vector
    •	Sequence to Sequence
    •	Vector to Sequence
    •	Encoder- Decoder

## Week 5 - 20 July to 26 July
Recurrent Neural Network (RNNs) contd.
  
    •	Recurrent dropout
    •	Sequence data examples: Speech recognition, Music generation, Sentiment classification, 
    Machine Translation, Video activity recognition, Named Entity Recognition.
    •	Word Embeddings: This can be thought as a technique for dimensionality reduction. 
    Embeddings can be leared and used as input to LSTM/sequence models.
    •	Bidirectional RNNs - Prediction of state at current time t may depend on the whole input sequence.
    (i.e. based not just on past events but based on future events as well) Ex: Speech recognition.
    Bidirectional RNNs is the solution.
    •	Combining CNNs and RNNs - 1 D convolutions. 
    Example: Important features of long sequences are extracted through CNNs and fed into RNNs.

AutoEncoders
  
    •	Outputs are called reconstructions.
    •	Cost function is based on reconstruction loss that meausures deviations of input from output.
    •	Dimensionality of the internal representation is lower - the autoencoder is called "undercomplete". 
    The inner layer has to learn the most important features.
    
    •	PCA via Undercomplete Auto encoders. 
    Auto encoders consists of 2 components. Encoder and Decoder.
    Coding can be learnt via auto encoders. They are the units with the least number of neurons.
    •	Stacked Auto-encoders - Layer of encoders. Helps better learn codings.
    •	Visualization via t-SNE
    •	Unsupervised Pretraining using Autoencoders - What if most of the labels are missing? 
    Use Autoencoders
    •	Convolutional Autoencoders - Convolution layers can be used to learn codings.
    •	Recurrent Autoencoders - RNNs can be used to learn codings.
    •	Stacked Denosing Autoencoders - force the autoencoder to learn useful feature by adding noise.
    •	Sparse Autoencoders - Most of the activations are close to 0. 
    Done by adding sigmoid activation function in the coding layer
 
 ## Week 6 - 27 July to 02 Aug
  
    Stacked Denoising Auto Encoders
      •	Gaussian noise is added to the input. Auto encoder still captures important features.
      Done to avoid over fitting. Helps learn most important features(codings)
 
    Sparse Auto Encoders 
      •	Sparse Auto Encoders - When we are not sure about the number of coding units
      •	Created by adding penalty term. Penalty can be L1 or KL Divergence
    
    Variational Auto Encoders (VAE)
      •	Mean(mu) and variation(sigma) of each input is measured. To the mean add gussian noise(from sigma).
      VAE are similar to Auto enoders. But when noise is added the recreated image will look realistic.
      A contineous space is created. Contineous Space is created by using Latent Loss.
      Z(new)= Z + T S, where Z-> Space of codings, T-> scalar. S-> Vector in the space of codings Z.
     
    Generative Adversarial Networks (GANs)
      •	Adversarial - Because model is trying to trick another model.
      •	There are 2 phases(Generator part, Descriminator part)-
        •	Phase 1-Freeze Generator part. Give real and fake images NN will classify as Real and Fake.
        •	Phase 2-Freeze weights of Descriminator part. Train generator.
      •	Both Generator and Descriminator are fighting one another.
     	
     Deep Convolutional GANs
        • Vector Arithmetic for Visual Concepts -> Man with Glasses- Man + Women-> Women With Glasses
     Style GANs
        • The state of the art in high-resolution image generation.
        Used Style transfer techniques.
        • Composed of 2 Networks-
          Mapping Network - Mapping network maps the codings to multiple style vectors.
          Synthesis Network - Responsible for generating the images.
         
 ## Week 7 - 3 Aug to 9 Aug
 Reinforcement Learning - Agent needs to maximize expected cumilative reward.
 
    Techniques:
      •	Greedy policy - Best in current knowledge
      •	Epsilon Greedy - Epsilon probability to choose a different path.
      
  Action - Value and policy
   
    •	No: actions depend on the state.
    •	Current reward doesn't depend on past reward.
    •	The policy map gives the probability of taking action 'a' when in state 's'.
    • Action on the environment gives nest reward and next state.
      
  key terms:
   
    • Transition Probability - Probability of moving from one state to another.
    Probability depends on previous action and previous state.
    • Markov Process(MP) and Markov Decision Process (MDP)
    • Iterative algorithm. Pick a policy(pi)->evaluate value(q)->improve policy->evaluate value...
    • Q-Learning - Approximate the value of Action-value function. 
    Since its not required to get exact value since our policy is initially off.
    
    • Value(q*(s,a)) can be obtained from Bellman optimality equation.
    • SGD (Stochastic Gradient Descent) for control -
    q*(s,a) is approximately qhat(s,a,w)
    • Q-Learning with approximation(Ut)
    • Q_learning is biased therefore double Q_Learning was introduced.
    • Deep Q-Network - Q(s,a) in Q-Learning algorithm can be approximated via Deep NN.
    • Expereince Replay - Order of samples are changed and samples can be reused.
    This is called Expereince Replay.
### Final Project:

Identification of celebrities:

    Given an input image, the Deep Learning model compares among 33 different celbrities
    and displays the top 3 celebrity resemblence.

    Techniques used:
    • CNN
    • Transfer Learning - VGGFace
    • Face detection - MTCNN
    • Image Augmentation

### Quiz Scores:
      
    Quiz 1 score:  20/20
    Quiz 2 score:  20/20
    Quiz 3 score:  20/20
    Quiz 4 score:  20/20
    Quiz 5 score:  20/20
    Quiz 6 score:  20/20
    Quiz 7 score:  20/20
    Quiz 8 score:  20/20
    Quiz 9 score:  20/20
    Quiz 10 score: 20/20
    Quiz 11 score: 20/20
    Quiz 12 score: 20/20 (Bonus)
    
### HomeWork scores:

    HW 1 score: 65/65
    HW 2 score: 65/65
    HW 3 score: 65/65
    HW 4 score: 65/65
    HW 5 score: 65/65
    No More HW
    
 ### Project scores:

    Project Abstract: 2/2
    Code+Presentation: 13/13
    
 ### Course Grade: A 
